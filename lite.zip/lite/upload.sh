rsync -a --exclude='_*' . pi@192.168.178.29:~/VPlan
