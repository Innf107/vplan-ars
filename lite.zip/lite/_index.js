"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _this = this;
exports.__esModule = true;
var express = require("express");
var app = express.Router();
var request = require("request");
var util = require("util");
var requestAsync = util.promisify(request);
var device = require("express-device");
var fs = require("fs");
var xcss = require("prophet-xcss");
//#region start-end
//                                                                                               <button class="changeThemeButton" onclick=window.href = `${document.Url}/theme2`;return false;>Theme wechseln</button>
//                                                                                               I
//                                                                                              \/
/*const start = `<html>
                    <head>
                        <title>Vertretungsplan ARS</title>
                        <link rel="stylesheet" type="text/css" href="css/[CSS]">
                    </head>
                    <body>
                        <div class="lehrer">
                            <form action="">
                                Lehrer-Kuerzel
                                <input class="lehrerInput" type="text" name="teacher">
                                <br>
                                <input class="lehrerButton" type="submit" value="Filtern">
                            </form>
                        </div>`*/
var start = "<html>\n                    <head>\n                        <title>Vertretungsplan ARS</title>\n                        <link rel=\"stylesheet\" type=\"text/css\" href=\"css/[CSS]\">\n                    </head>\n                    <body>\n                        <p class=\"Credits\">Code: Finn Schneider</p>\n                        <p class=\"Credits\">Server: Finn Schneider</p>\n                        <p class=\"Credits\">Style:  Finn Beer</p>\n                        <a href=\"/dark\">Sieht das Layout falsch aus? Hier ist das alte Design!</a>";
//                  ...
var end = "       </body>\n                </html>";
//#endregion
var pollingRate = 1200000;
//#region teacher start-end
var teacherStart = "  <html>\n                            <head>\n                                <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\">\n                            </head>\n                            <body>";
//                          ...
var teacherEnd = "      </body>\n                        </html>";
//#endregion
var nonAsciiTeachers = {
    'GR�': 'GRß',
    'B�': 'BÜ',
    'B�T': 'BÖT'
};
var tables = ['table 0'];
var dates = [''];
var fullHtml = '';
var tablesOnly = '';
var filterTeacherHTML = '';
//TODO Interface
var vPlanJSON;
var auth = 'Basic ' + Buffer.from('vplan:ars2013').toString('base64');
var users = [];
app.use(xcss([__dirname + '/public/css'], { verbose: true }));
app.use(express.static(__dirname + '/public'));
app.use(device.capture());
//TODO               : Request ?
app.get('/dark', function (req, res) {
    var onMobile = req["device"].type == "phone";
    console.log("\u001B[35;1mget dark from " + req.ip + " onMobile: " + onMobile + "\u001B[0m");
    if (!onMobile)
        res.send(start.replace("[CSS]", 'styleDesktop.css') + fullHtml + end);
    else
        res.send(start.replace("[CSS]", 'styleMobile.css') + fullHtml + end);
});
app.get('/', function (req, res) {
    var teacherFilter = req.query.teacher;
    //console.log(teacherFilter)
    var thisHTML = processWithTeacherFilter(fullHtml, teacherFilter);
    //TODO
    var onMobile = req["device"].type == "phone";
    var ip = req.header('x-forwarded-for') || req.ip;
    console.log("\u001B[35;1mget from " + ip + " onMobile: " + onMobile + " at " + new Date(Date.now()) + "\u001B[0m");
    if (!onMobile) {
        res.send(start.replace("[CSS]", 'styleNew.css') + thisHTML + end);
    }
    else
        res.send(start.replace("[CSS]", 'styleNew.css') + thisHTML + end);
    if (users.every(function (entry) { return entry.ip != ip; }))
        users.push({ ip: ip, time: Date.now() });
    //cleanupUsers()            remove? 
    console.log("user count since startup: " + users.length);
});
app.get('/filter-lehrer', function (req, res) {
    console.log("\u001b[35;1mget lehrer " + req.ip + '\u001b[0m');
    res.send(teacherStart + filterTeacherHTML + teacherEnd);
});
app.get('/logs', function (req, res) {
    var logPath = "/var/log/startup.log";
    var logs = fs.readFileSync(logPath);
    res.send(logs);
});
app.get('/experimental', function (req, res) {
    var file = fs.readFileSync(__dirname + '/public/experimental.html').toString();
    var dates = vPlanJSON.dates.map(function (d) { return d.date; });
    var selected = req.query.date;
    var ret = file.replace('[dates]', dates.map(function (d) { return "<option value=\"" + d + "\">" + d + "</option>"; }))
        .replace('[table]', dateToHtml(vPlanJSON.dates.find(function (d) { return d.date === selected; })));
    res.send(ret);
});
app.post('/update', function (req, res) {
    console.log('updating from manual request!!');
    res.send();
    main();
});
var fileExtension = { 'windows': '.exe', 'linux': '' };
app.post('/update-self', function (req, res) {
    var ip = req.header('x-forwarded-for') || req.ip;
    console.log("sending latest cli tools to " + ip);
    var os = req.query.os;
    res.sendFile(__dirname + ("/public/cli/" + os + "/pi" + fileExtension[os]));
});
app.get('/json', function (req, res) { return res.send(vPlanJSON); });
var updateJSON = function () {
    //TODO
    try {
        var json = {};
        var dateFullRegex = /[^]{1,10000}(<p class="Date">.{1,35}<\/p>)/g;
        var klasseFullRegex_1 = /<td class=\\?"list inline_header\\?" colspan=\\?"5\\?" >[^_]{1,5000}(?=(<td class=\\?"list i)|$)/g;
        var klasseRegex_1 = /<td class=\"list inline_header\" colspan=\"5\" >.{0,25}<\/td>/g;
        var hourRegex_1 = /(?<=>)[\d -]{1,15}<[^#]{1,360}(?=(<td class=\\?\"list\\?\" align=\\?\"center\\?\">[\d -]+)|$)/g;
        var dateRegex_1 = /(?<=Date\">).{0,30}(?=<\/p>)/;
        var timeRegex_1 = /^[\d -]+/;
        //TODO
        var infoRegex_1 = /(?<=(<td class=\"list\" align=\"center\">)).{1,30}(?=<\/td>)/g;
        var dateStrs = [];
        var dates_1 = [];
        for (var _i = 0, _a = fullHtml.match(dateFullRegex); _i < _a.length; _i++) {
            var h = _a[_i];
            if (h != null)
                dateStrs.push(h);
        }
        dateStrs.forEach(function (date, i) {
            dates_1.push({ klassen: [] });
            for (var _i = 0, _a = date.match(klasseFullRegex_1); _i < _a.length; _i++) {
                var k = _a[_i];
                var hours = k.match(hourRegex_1);
                dates_1[i].klassen.push({
                    klasse: k.match(klasseRegex_1)[0]
                        .replace("<td class=\"list inline_header\" colspan=\"5\" >", '')
                        .replace("</td>", ''),
                    hours: hours.map(function (h) {
                        var info = h.match(infoRegex_1).map(function (s) { return s
                            .replace('<s>', '')
                            .replace('</s>', ''); });
                        return {
                            stunde: h.match(timeRegex_1)[0],
                            Vertreter: info[0],
                            Fach: info[1],
                            Raum: info[2],
                            VertretungsText: info[3]
                        };
                    })
                });
            }
            dates_1[i].date = date.match(dateRegex_1)[0];
        });
        json["dates"] = dates_1;
        vPlanJSON = json;
    }
    catch (e) {
        console.log("error updating JSON: [TODO: Add error message in here]");
    }
};
var content = '';
var dateToHtml = function (dateJSON) {
    if (dateJSON === undefined)
        return '';
    var ht = '';
    dateJSON.klassen.forEach(function (k) {
        ht +=
            "<table class=\"table\">\n         <th class=\"klasse\">" + k.klasse + "</th>";
        for (var _i = 0, _a = k.hours; _i < _a.length; _i++) {
            var h = _a[_i];
            ht +=
                "<tr class=\"even\">\n                <td class=\"Stunde\">" + h.stunde + "</td>\n                <td class=\"Vertreter\">" + h.Vertreter + "</td>\n                <td class=\"Fach\">" + h.Fach + "</td>\n                <td class=\"Raum\">" + h.Raum + "</td>\n                <td class=\"VText\">" + h.VertretungsText + "</td>\n             </tr>";
        }
    });
    return ht;
};
var processWithTeacherFilter = function (inHTML, teacher) {
    //                              list odd
    //                                  or
    //                              list even
    //const filterRegex = new RegExp(`<tr class='list [oe][dv][de]n?'><td class="list" align="center"><s>${teacher}<\/s>[^]*<\/td>[^]*<\/tr>`);
    //const filterRegex = new RegExp(`<tr class='list [oe][dv][de]n?'>[^]?<td class="list" align="center">[^]*<s>`)
    var filterRegex = new RegExp("<tr class='list [oe][dv][de]n?'>[^]?<td class=\"list\" align=\"center\">[^]?.{0, 7}[^]?</td>[^]?<td class=\"list\" align=\"center\">[^]?<s>[^]?" + teacher + "[^]?</s>[^]?.{0,4}[^]?</td>[^]?<td class=\"list\" align=\"center\">[^]?.+[^]?</td>[^]?<td class=\"list\" align=\"center\">[^]?.*[^]?</td>[^]?<td class=\"list\" align=\"center\">[^]?.+[^]?</td>[^]?</tr>");
    //const filterRegex = new RegExp(`<s>${teacher}<\/s`)
    var results = filterRegex.exec(inHTML);
    //console.log('contains teacher: ' + results)
    if (results == null)
        return inHTML;
    return inHTML;
};
var filterTeacher = function () {
    console.log('filtering by teacher');
    var rowRegex = /<tr class='list even'>[^]*>/;
    var found = rowRegex.exec(tablesOnly);
    //console.log('found: ' + found + '\n\n\n')
    filterTeacherHTML = tablesOnly;
};
var main = function () { return __awaiter(_this, void 0, void 0, function () {
    var index, tableRegex, dateRegex, dateRes;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                console.log("Updating...");
                index = 1;
                _a.label = 1;
            case 1:
                if (!(index <= 12)) return [3 /*break*/, 4];
                console.log("trying to get the html at " + index);
                tableRegex = /<table class="mon_list"[^]+<\/table>/;
                dateRegex = /\d{1,2}\.\d{1,2}\.20\d\d [A-Za-z]+, Woche [AB]/;
                return [4 /*yield*/, requestAsync({
                        url: "https://vplan.ars-hochtaunus.de/subst_" + index.toString().padStart(3, '0') + ".htm",
                        headers: {
                            'Authorization': auth
                        }
                    })];
            case 2:
                content = (_a.sent()).body;
                console.log('valid: ' + !(content == ''));
                if (content == '')
                    return [3 /*break*/, 3];
                dateRes = dateRegex.exec(content);
                if (dateRes == null)
                    return [3 /*break*/, 3];
                dates[index] = dateRes[0];
                tables[index] = tableRegex.exec(content)[0];
                _a.label = 3;
            case 3:
                index++;
                return [3 /*break*/, 1];
            case 4:
                console.log("combining...");
                fullHtml = combine(tables);
                console.log("done combining!\nUpdating JSON");
                updateJSON();
                console.log("Done updating JSON");
                setTimeout(main, pollingRate);
                setTimeout(filterTeacher, pollingRate + 1200);
                console.log("updated at " + new Date(Date.now()));
                return [2 /*return*/];
        }
    });
}); };
var combine = function (ts) {
    var openEndF = function (s) { return s.toString().replace('</table>', ''); };
    var openStartF = function (s) { return s.toString().replace('</table>', ''); };
    var open = function (s) { return openStartF(openEndF(s)); };
    tablesOnly = '';
    var fullHtml2 = '';
    var lastDate = '';
    for (var i = 1; i < ts.length; i++) {
        if (ts[i] == null) {
            continue;
        }
        var str = void 0;
        if (i === 1)
            str = openEndF(ts[i]);
        else if (i === ts.length - 1)
            str = openStartF(ts[i]);
        else
            str = open(ts[i]);
        var curDate = dates[i - 1];
        if (curDate != null && lastDate !== curDate) {
            fullHtml2 += "<p class=\"Date\">" + dates[i - 1] + "</p>";
            lastDate = curDate;
        }
        fullHtml2 += str;
        tablesOnly += str;
    }
    fullHtml2 += "<p class=\"Date\">" + dates[ts.length - 1] + "</p>";
    return replaceAsciiTeachers(fullHtml2);
};
var replaceAll = function (str, key, replace) { return !str.includes(key) ? str : replaceAll(str.replace(key, replace), key, replace); };
var replaceAsciiTeachers = function (s) {
    for (var key in nonAsciiTeachers) {
        if (s.includes(key)) {
            console.log("key: " + key);
            s = replaceAll(s, key, nonAsciiTeachers[key]);
        }
    }
    return replaceAll(s, '�', 'Ä');
};
main();
filterTeacher();
console.log("\n\nrunning on port: " + 5000);
//Test
module.exports = app;
