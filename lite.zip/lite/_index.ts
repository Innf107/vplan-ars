import {Response, Express} from "express"
import  * as express from "express" 
const app = express.Router() 
const request = require("request")
const util = require("util")
const requestAsync = util.promisify(request)
const device = require("express-device")
const fs = require("fs")
const xcss = require("prophet-xcss")

//#region start-end
//                                                                                               <button class="changeThemeButton" onclick=window.href = `${document.Url}/theme2`;return false;>Theme wechseln</button>
//                                                                                               I
//                                                                                              \/
/*const start = `<html>
                    <head>
                        <title>Vertretungsplan ARS</title>
                        <link rel="stylesheet" type="text/css" href="css/[CSS]">
                    </head>
                    <body>
                        <div class="lehrer">
                            <form action="">
                                Lehrer-Kuerzel
                                <input class="lehrerInput" type="text" name="teacher">
                                <br>
                                <input class="lehrerButton" type="submit" value="Filtern">
                            </form>
                        </div>`*/
const start =  `<html>
                    <head>
                        <title>Vertretungsplan ARS</title>
                        <link rel="stylesheet" type="text/css" href="css/[CSS]">
                    </head>
                    <body>
                        <p class="Credits">Code: Finn Schneider</p>
                        <p class="Credits">Server: Finn Schneider</p>
                        <p class="Credits">Style:  Finn Beer</p>
                        <a href="/dark">Sieht das Layout falsch aus? Hier ist das alte Design!</a>`
//                  ...
const end = `       </body>
                </html>`
//#endregion

const pollingRate = 1200000

//#region teacher start-end
const teacherStart = `  <html>
                            <head>
                                <link rel="stylesheet" type="text/css" href="css/style.css">
                            </head>
                            <body>`
//                          ...
const teacherEnd   = `      </body>
                        </html>`
//#endregion

const nonAsciiTeachers = {
    'GR�' : 'GRß',
    'B�'  : 'BÜ',
    'B�T' : 'BÖT'
}

let tables = ['table 0']
let dates = ['']
let fullHtml = ''

let tablesOnly = ''
let filterTeacherHTML = ''

//TODO Interface
let vPlanJSON

const auth = 'Basic ' + Buffer.from('vplan:ars2013').toString('base64')

let users : {ip : string, time : number}[] = []


app.use(xcss([__dirname + '/public/css'], {verbose:true}))
app.use(express.static(__dirname + '/public'));
app.use(device.capture())

//TODO               : Request ?
app.get('/dark', (req, res : Response) => {
    const onMobile = req["device"].type == "phone"
    console.log(`\u001b[35;1mget dark from ${req.ip} onMobile: ${onMobile}\u001b[0m`);
    if(!onMobile)
        res.send(start.replace("[CSS]", 'styleDesktop.css') + fullHtml + end)
    else
        res.send(start.replace("[CSS]", 'styleMobile.css') + fullHtml + end)
})
app.get('/', (req, res : Response) => {

    const teacherFilter : string = req.query.teacher
    //console.log(teacherFilter)

    const thisHTML = processWithTeacherFilter(fullHtml, teacherFilter)

    //TODO
    const onMobile = req["device"].type == "phone"
    const ip : string = req.header('x-forwarded-for') || req.ip
    console.log(`\u001b[35;1mget from ${ip} onMobile: ${onMobile} at ${new Date(Date.now())}\u001b[0m`);
    if(!onMobile)
    {
        res.send(start.replace("[CSS]", 'styleNew.css') + thisHTML + end)
    }
    else
        res.send(start.replace("[CSS]", 'styleNew.css') + thisHTML + end)

    if(users.every(entry => entry.ip != ip))
        users.push({ip: ip, time: Date.now()})
    //cleanupUsers()            remove? 

    console.log(`user count since startup: ${users.length}`)
})
app.get('/filter-lehrer', (req, res) => {
    console.log("\u001b[35;1mget lehrer " + req.ip + '\u001b[0m')
    res.send(teacherStart + filterTeacherHTML + teacherEnd)
})

app.get('/logs', (req, res : Response) => {
    const logPath = "/var/log/startup.log";
    const logs = fs.readFileSync(logPath)
    res.send(logs)
})

app.get('/experimental', (req, res) => {
    const file = fs.readFileSync(__dirname + '/public/experimental.html').toString()

    const dates = vPlanJSON.dates.map(d => d.date)
    const selected = req.query.date


    const ret = file.replace('[dates]', dates.map(d => `<option value="${d}">${d}</option>`))
                    .replace('[table]', dateToHtml(vPlanJSON.dates.find(d => d.date === selected)))

    res.send(ret)
})

app.post('/update', (req, res) => {
    console.log('updating from manual request!!')
    res.send()
    main()
})

const fileExtension = {'windows':'.exe', 'linux':''}

app.post('/update-self', (req, res) => {
    const ip = req.header('x-forwarded-for') || req.ip
    console.log(`sending latest cli tools to ${ip}`)
    const os = req.query.os;

    res.sendFile(__dirname + `/public/cli/${os}/pi${fileExtension[os]}`)
})


app.get('/json', (req, res) => res.send(vPlanJSON))

const updateJSON = () => {
    //TODO
    try
    {
        
        let json = {}
        

        const dateFullRegex = /[^]{1,10000}(<p class="Date">.{1,35}<\/p>)/g
        const klasseFullRegex = /<td class=\\?"list inline_header\\?" colspan=\\?"5\\?" >[^_]{1,5000}(?=(<td class=\\?"list i)|$)/g
        const klasseRegex = /<td class=\"list inline_header\" colspan=\"5\" >.{0,25}<\/td>/g
        const hourRegex = /(?<=>)[\d -]{1,15}<[^#]{1,360}(?=(<td class=\\?\"list\\?\" align=\\?\"center\\?\">[\d -]+)|$)/g
        const dateRegex = /(?<=Date\">).{0,30}(?=<\/p>)/
        const timeRegex = /^[\d -]+/
        //TODO
        const infoRegex = /(?<=(<td class=\"list\" align=\"center\">)).{1,30}(?=<\/td>)/g

        let dateStrs = []
        let dates = []
        
        for(const h of fullHtml.match(dateFullRegex))
        {
            if(h != null)
                dateStrs.push(h)
        }
        dateStrs.forEach((date, i) => {
            dates.push({klassen:[]})
            for(const k of date.match(klasseFullRegex)){
                const hours = k.match(hourRegex)
                dates[i].klassen.push({
                    klasse: k.match(klasseRegex)[0]
                        .replace("<td class=\"list inline_header\" colspan=\"5\" >", '')
                        .replace("</td>", ''),

                    hours: hours.map(h => {
                        const info = h.match(infoRegex).map(s => s
                            .replace('<s>', '')
                            .replace('</s>', ''))
                        
                        return {
                            stunde: h.match(timeRegex)[0],
                            Vertreter: info[0],
                            Fach: info[1],
                            Raum: info[2],
                            VertretungsText: info[3] 
                        }
                    })
                })
            }
            dates[i].date = date.match(dateRegex)[0]
        })

        json["dates"] = dates;

        vPlanJSON = json;
    }
    catch(e)
    {
        console.log(`error updating JSON: [TODO: Add error message in here]`)
    }
}



let content = '';

const dateToHtml = (dateJSON) => {
    if(dateJSON === undefined)
        return ''
    
    let ht = ''
    dateJSON.klassen.forEach(k => {
        ht += 
        `<table class="table">
         <th class="klasse">${k.klasse}</th>`
         for(const h of k.hours){
            ht += 
            `<tr class="even">
                <td class="Stunde">${h.stunde}</td>
                <td class="Vertreter">${h.Vertreter}</td>
                <td class="Fach">${h.Fach}</td>
                <td class="Raum">${h.Raum}</td>
                <td class="VText">${h.VertretungsText}</td>
             </tr>`
         }
    })
    return ht;
}

const processWithTeacherFilter = (inHTML, teacher) => {
    //                              list odd
    //                                  or
    //                              list even
    //const filterRegex = new RegExp(`<tr class='list [oe][dv][de]n?'><td class="list" align="center"><s>${teacher}<\/s>[^]*<\/td>[^]*<\/tr>`);
    //const filterRegex = new RegExp(`<tr class='list [oe][dv][de]n?'>[^]?<td class="list" align="center">[^]*<s>`)
    const filterRegex = new RegExp(`<tr class='list [oe][dv][de]n?'>[^]?<td class="list" align="center">[^]?.{0, 7}[^]?</td>[^]?<td class="list" align="center">[^]?<s>[^]?${teacher}[^]?</s>[^]?.{0,4}[^]?</td>[^]?<td class="list" align="center">[^]?.+[^]?</td>[^]?<td class="list" align="center">[^]?.*[^]?</td>[^]?<td class="list" align="center">[^]?.+[^]?</td>[^]?</tr>`)
    //const filterRegex = new RegExp(`<s>${teacher}<\/s`)
    const results = filterRegex.exec(inHTML);
    
    //console.log('contains teacher: ' + results)

    if(results == null)
        return inHTML;

    return inHTML
}

const filterTeacher = () => {
    console.log('filtering by teacher')

    const rowRegex = /<tr class='list even'>[^]*>/
    const found = rowRegex.exec(tablesOnly);
    //console.log('found: ' + found + '\n\n\n')

    filterTeacherHTML = tablesOnly
}

const main = async () => {
    console.log("Updating...")

    for(let index = 1; index <= 12; index++)
    {
        console.log("trying to get the html at " + index)
    
        const tableRegex = /<table class="mon_list"[^]+<\/table>/
        const dateRegex = /\d{1,2}\.\d{1,2}\.20\d\d [A-Za-z]+, Woche [AB]/

        content = (await requestAsync(
            {
                url: `https://vplan.ars-hochtaunus.de/subst_${index.toString().padStart(3, '0')}.htm`,
                headers : {
                    'Authorization' : auth
                }
            })).body

        console.log('valid: ' + !(content == ''))
        if(content == '')
            continue;

            const dateRes = dateRegex.exec(content)
            if(dateRes == null)
                continue;
            dates[index] = dateRes[0]
            tables[index] = tableRegex.exec(content)[0]
    }
    console.log("combining...")
    fullHtml = combine(tables)
    console.log("done combining!\nUpdating JSON")
    updateJSON();
    console.log("Done updating JSON")
    setTimeout(main, pollingRate)
    setTimeout(filterTeacher, pollingRate + 1200)
    console.log(`updated at ${new Date(Date.now())}`)
}

const combine = ts => {
    const openEndF = s => s.toString().replace('</table>', '')
    const openStartF = s => s.toString().replace('</table>', '')
    const open = s => openStartF(openEndF(s))

    tablesOnly = ''
    let fullHtml2 = ''
    let lastDate = ''
    for(let i = 1; i < ts.length; i++)
    {
        if(ts[i] == null)
        {
            continue
        }

        let str
        if(i === 1)
            str = openEndF(ts[i])
        else if(i === ts.length - 1)
            str = openStartF(ts[i])
        else
            str = open(ts[i])

        const curDate = dates[i - 1]
        if(curDate != null && lastDate !== curDate)
        {
            fullHtml2 += `<p class="Date">${dates[i-1]}</p>`
            lastDate = curDate
        }
        fullHtml2 += str
        tablesOnly += str
    }
    fullHtml2 += `<p class="Date">${dates[ts.length - 1]}</p>`
    return replaceAsciiTeachers(fullHtml2)
}

const replaceAll = (str, key, replace) => !str.includes(key) ? str : replaceAll(str.replace(key, replace), key, replace)

const replaceAsciiTeachers = s => {
    for (const key in nonAsciiTeachers) 
    {
        if (s.includes(key)){
            console.log("key: " + key)
            s = replaceAll(s, key, nonAsciiTeachers[key])
        }
    }
    return replaceAll(s, '�', 'Ä');
}

main()
filterTeacher()

console.log("\n\nrunning on port: " + 5000)
//Test
module.exports = app